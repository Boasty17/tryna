module.exports.run = async (bot, message, args) => {

  var embed = new Discord.RichEmbed()
      .setColor('00cbff') //mec pk ta retirer C koi cette couleur Blue Ok
      .setDescription("**Info du serveur Discord**") //tu peUx maider avec le clear? oui Mrc
      .addField("Nom du serveur", message.guild.name, false)
      .addField("Cree le", message.guild.createdAt, true)
      .addField("Tu a rejoins le", message.member.joinedAt, true)
      .addField("Membres sur le serveur", message.guild.memberCount, false)
      .setFooter("ServerInfo - Mars")
  message.channel.sendEmbed(embed)
}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["serverinfo"],
};

exports.help = {
  name: "serverinfo",
  description: "",
  usage: "serverinfo"
};