module.exports.run = async (bot, message, args) => {

  var sayings = ["Oui", "Non", "Peut-être", "Peut-être pas", "Certainement", "Certainement pas", "Bien-sûr!", "Pas-sûr...", ]

  var result = Math.floor((Math.random() * sayings.length) + 0);
  const embed = new Discord.RichEmbed()
      .setColor("000000")
      .setTitle("8ball")
      .addField(args, sayings[result])
  message.channel.send({
      embed: embed
  })
}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["8ball"],
};

exports.help = {
  name: "8ball",
  description: "",
  usage: "8ball"
};