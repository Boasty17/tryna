module.exports.run = async (bot, message, args) => {

  if (!message.member.roles.some(r => ["Administrator", "Moderator", "Admin", "Modo", "Createur", "Fondateur", ].includes(r.name)))
      return message.reply("Desolé! Tu n'as pas les permissions!");

  let member = message.mentions.members.first() || message.guild.members.get(args[0]);
  if (!member)
      return message.reply("Mentionnez une personne dans le serveur");
  if (!member.kickable)
      return message.reply("Je ne peut pas le kick! Ont-il un role plus haut? Est-ce que j'ai les permissions de kick?");

  let reason = args.slice(1).join(' ');
  if (!reason) reason = "Pas de raison fournie";

  await member.kick(reason)
      .catch(error => message.reply(`Desolé ${message.author}, Je n'ai pas pu kick la personne a cause de : ${error}`));
  message.reply(`${member.user.tag} a été kick par ${message.author.tag} a cause de: ${reason}`);

}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["kick"],
};

exports.help = {
  name: "kick",
  description: "",
  usage: "kick"
};