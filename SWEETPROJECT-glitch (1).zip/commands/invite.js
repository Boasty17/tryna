module.exports.run = async (bot, message, args) => {

  var help_embed = new Discord.RichEmbed()
      .setColor("000000")
      .setTitle("Invitation")
      .addField("Invitez le bot sur votre serveur!", "https://discordapp.com/oauth2/authorize?client_id=477103261279715403&scope=bot&permissions=268443710")
      .setFooter("Invite - Mars")
  message.channel.send(help_embed);
}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["invite"],
};

exports.help = {
  name: "invite",
  description: "",
  usage: "invite"
};