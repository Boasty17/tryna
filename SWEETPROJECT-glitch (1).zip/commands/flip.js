module.exports.run = async (bot, message, args) => {

  var result = Math.floor((Math.random() * 2) + 1);
  if (result == 1) {
      client.reply(message, "La piece est tomber sur pile");
  } else if (result == 2) {
      client.reply(message, "La piece est tomber sur face");
  }
}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["flip"],
};

exports.help = {
  name: "flip",
  description: "",
  usage: "flip"
};