module.exports.run = async (bot, message, args) => {

    const m = await message.channel.send("Ping?");
    m.edit(`Pong! :ping_pong: La latence est de ${m.createdTimestamp - message.createdTimestamp}ms. La latence de l'API est de ${Math.round(client.ping)}ms`);

}

exports.conf = {
    enabled: false,
    guildOnly: true,
    aliases: ["ping"],
};

exports.help = {
    name: "ping",
    description: "",
    usage: "ping"
};