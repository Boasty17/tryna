module.exports.run = async (bot, message, args) => {

  var help_embed = new Discord.RichEmbed()
      .setColor("000000")
      .setTitle("Help!")
      .addField("Bonjour", "Le bot vous répondera!")
      .addField("m!help", "La commande d'aide du bot")
      .addField("m!invite", "La commande d'invite du bot")
      .addField("m!info", "Donne des info sur le bot")
      .addField("m!say", "Le bot répétera ce que vous dites !") //
      .addField("m!ping", "Donne le ping")
      .addField("m!avatar", "Montre votre avatar")
      .addField("m!serverinfo", "Montre les info du serv")
      .addField("m!clear", "Efface des message!")
      .addField("m!ban", "Bannez une personne")
      .addField("m!kick", "Kickez une personne")
      .addField("m!ban", "Bannez une personne")
      .addField("m!8ball", "Avez une question? 8ball va vous repondre! (Beta)")
      .addField("m!reporterror", "Reportez une erreur sur le discord de Mars! (**NE METTEZ AUCUNE ESPACE. METTEZ DES TIRET (-) OU DES (_)**")
      .setFooter("Help - Mars")
  message.member.send(help_embed);
  message.channel.send("Regarde tes MP! :eyes:")
  console.log("Un utilisateur a demandé de l'aide")
}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["help"],
};

exports.help = {
  name: "help",
  description: "",
  usage: "help"
};