module.exports.run = async (bot, message, args) => {

  var inf_embed = new Discord.RichEmbed()
      .setColor('00cbff')
      .setDescription("**Info sur moi**")
      .addField("Nom:", "Mars", true)
      .addField("Créateur:", "LunatiikXD", true)
      .addField("Version (discord.js):", `${require('discord.js').version}`)
      .addField(`Serveurs:`, `${client.guilds.size} serveur(s)`, false)
      .addField(`Utilisateurs:`, `${client.users.size} personnes utilisent Mars`, false)
      .addField("Serveur Discord:", "https://discord.gg/fk2edmu")
      .setThumbnail(client.user.avatarURL)
      .setFooter("Info - Mars")
  message.member.sendEmbed(inf_embed)

  //message.member.send(`:eyes:Info sur moi:eyes:\nNom: Mars\nCreateur: LunatiikXD\nCreer avec discord.js 11.4.0\nJe suis sur ${client.guilds.size} serveurs !`)
  message.reply("Regarde tes MP! :eyes: ")
}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["info"],
};

exports.help = {
  name: "info",
  description: "",
  usage: "info"
};