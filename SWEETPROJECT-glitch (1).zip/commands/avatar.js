module.exports.run = async (bot, message, args) => {

  var help_embed = new Discord.RichEmbed()
      .setColor("000000")
      .setTitle("Avatar")
      .setImage(message.author.avatarURL)
      .setFooter("Avatar - Mars")
  message.channel.sendEmbed(help_embed);
}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["ping"],
};

exports.help = {
  name: "ping",
  description: "",
  usage: "ping"
};