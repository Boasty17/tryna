module.exports.run = async (bot, message, args) => {

  const deleteCount = parseInt(args[0], 10);

  if (!deleteCount || deleteCount < 2 || deleteCount > 100)
      return message.reply("Mettez un nombre entre 2 et 100 pour effacer les messages");
  if (!message.member.roles.some(r => ["Administrator"].includes(r.name)))
      return message.reply("Sorry, you don't have permissions to use this!");
  const fetched = await message.channel.fetchMessages({
      limit: deleteCount
  });
  message.channel.bulkDelete(fetched)
      .catch(error => message.reply(`Je n'ai pas reussi a effacer les message a cause de: ${error}`));

}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["clear"],
};

exports.help = {
  name: "clear",
  description: "",
  usage: "clear"
};