module.exports.run = async (bot, message, args) => {

  const sayMessage = args.join(" ");

  message.delete().catch(O_o => {});

  message.channel.send(sayMessage);

}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["say"],
};

exports.help = {
  name: "say",
  description: "",
  usage: "say"
};