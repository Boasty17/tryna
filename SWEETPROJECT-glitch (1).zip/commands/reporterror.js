module.exports.run = async (bot, message, args) => {

  if (!args.length) {
      return message.channel.send(`Tu n'as pas fournie d'erreur!, ${message.author}!`)
  } else if (args[0] === `${message}`) {
      return message.channel.send();
  }

  bot.channels.get("480884109858832404").send(`${message.author.tag} a signaler une erreur. L'erreur est: ${args[0]}`)
}

exports.conf = {
  enabled: false,
  guildOnly: true,
  aliases: ["reporterror"],
};

exports.help = {
  name: "reporterror",
  description: "",
  usage: "reporterror"
};