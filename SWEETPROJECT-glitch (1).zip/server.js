// Load up the discord.js library
const Discord = require("discord.js");
const client = new Discord.Client();
const express = require("./express.js");
const fs = require("fs");

const config = require("./config.json");
let guildArray = client.guilds.array();
require('./utils/eventLoader')(client);

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();

fs.readdir('./commands/', (err, files) => {
    if (err) console.error(err);
    files.forEach(f => {
        let props = require(`./commands/${f}`);
        client.commands.set(props.help.name, props);
        props.conf.aliases.forEach(alias => {
            client.aliases.set(alias, props.help.name);
        });
    });
});

client.reload = command => {
    return new Promise((resolve, reject) => {
        try {
            delete require.cache[require.resolve(`./commands/${command}`)];
            let cmd = require(`./commands/${command}`);
            client.commands.delete(command);
            client.aliases.forEach((cmd, alias) => {
                if (cmd === command) client.aliases.delete(alias);
            });
            client.commands.set(command, cmd);
            cmd.conf.aliases.forEach(alias => {
                client.aliases.set(alias, cmd.help.name);
            });
            resolve();
        } catch (e) {
            reject(e);
        }
    });
};

client.on("guildCreate", guild => {
    console.log(`New guild joined: ${guild.name} (id: ${guild.id}). This guild has ${guild.memberCount} members!`);
    client.user.setActivity(`m!help | Sur ${client.guilds.size} serveurs`);
    var found = false;
    guild.channels.forEach(function(channel, id) {
        if (found == true || channel.type != "text") {
            return;
        }
        if (guild.me.permissionsIn(channel).has("SEND_MESSAGES") && guild.me.permissionsIn(channel).has("VIEW_CHANNEL")) {
            found = true;
            return channel.send("Hey, je suis Mars, Merci de m'avoir invité dans le serveur! Voir mes commandes est facile, faites m!help. Oh, vous voulez mon discord? Voila le lien! :https://discord.gg/fk2edmu")
            console.log("Server joined")
        }
    })
});

client.on("guildDelete", guild => {
    console.log(`I have been removed from: ${guild.name} (id: ${guild.id})`);
    client.user.setActivity(`m!help | Sur ${client.guilds.size} serveurs`);
});

client.on("guildMemberAdd", member => {
    member.guild.channels.find("name", "bienvenue", "discutage", "join-leave", "welcome").send(`Bienvenue ${member} !`)
});

client.on("guildMemberRemove", member => {
    member.guild.channels.find("name", "bienvenue", "discutage", "join-leave", "welcome").send(`${member} nous a quitté..`)
});


client.login(config.token);