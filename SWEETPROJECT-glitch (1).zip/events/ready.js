const Discord = require("discord.js");
const client = new Discord.Client();

module.exports = async (client, message, args) => {
    //Envoie un message dans la console pour dire que le client est en ligne
    console.log(`${client.user.username} est en ligne ! Serveur ${client.guilds.size} pour ${client.users.size} membres`);

    //Met une activité
    client.user.setActivity(`m!help | Sur ${client.guilds.size} serveurs`, {
        type: "PLAYING" //PLAYING, STREAMING, LISTENING, WATCHING
    });


}